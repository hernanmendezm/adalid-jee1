#!/bin/bash
GLASSFISH_HOME=/opt/glassfish-4.0/glassfish
JBOSS_HOME=/opt/jboss-as-7.1.1.Final
POSTGRESQL_HOME=/opt/PostgreSQL/9.2
POSTGRESQL_DRIVER_VERSION=9.2-1002 # 9.3-1102 for PostgreSQL 9.3
